export const name = 'remoteStructureRenderer' as const

export const ManifestManagerSymbol = Symbol('ManifestManager')
