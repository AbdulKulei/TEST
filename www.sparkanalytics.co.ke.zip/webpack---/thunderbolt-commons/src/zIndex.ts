export const MAX_Z_INDEX = '100000'
export const PORTALS_Z_INDEX = '100001'
export const BLOCKING_LAYER_BG_Z_INDEX = '99990'
