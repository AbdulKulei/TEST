export const name = 'modelUpdatesInvoker' as const
export const ModelUpdatesInvoker = Symbol('modelUpdatesInvokerSymbol')
export const ModelUpdatesHandlersImplementor = Symbol('modelUpdatesHandlersImplementorSymbol')
export const ViewerBatchingManagerSymbol = Symbol('ViewerBatchingManager')
