export const name = 'navigationPhases' as const

export const NavigationPhasesSymbol = Symbol('navigationPhases')
