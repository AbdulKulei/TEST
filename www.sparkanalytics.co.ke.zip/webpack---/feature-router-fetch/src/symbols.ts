export const name = 'routerFetch' as const
export const RouterFetchSymbol = Symbol('routerFetch')
