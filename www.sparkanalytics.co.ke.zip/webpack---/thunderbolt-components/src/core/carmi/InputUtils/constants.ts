export const minimumLabelFontSize = 16
export const labelPaddingLimit = 20
