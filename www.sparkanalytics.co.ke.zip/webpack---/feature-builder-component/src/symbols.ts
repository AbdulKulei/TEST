export const name = 'builderComponent' as const
export const BuilderComponentsLoaderSymbol = Symbol('BuilderComponentsLoader')
