export const name = 'pageAnchors' as const
