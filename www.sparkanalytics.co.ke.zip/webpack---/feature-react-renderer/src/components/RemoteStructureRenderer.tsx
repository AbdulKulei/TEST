import React, { ComponentType, useContext } from 'react'
import type { RendererProps } from '../types'
import { extendStoreWithSubscribe } from './extendStoreWithSubscribe'
import Context from './AppContext'
import StructureComponent from './StructureComponent'
import type { Structure } from '@wix/thunderbolt-becky-types'
import { AppStructure, PropsMap } from '@wix/thunderbolt-symbols'
import { getStore } from 'feature-stores'

interface RemoteStructureRendererProps {
	id: string
	structure: Structure
	compProps: Record<string, any>
	rootCompId: string
	stateRefs: Record<string, any>
	compPathsToSelectors: string
}

interface StyleCompProps {
	compId: string
	compPaths: string
}

const CompPathsStyleComp: ComponentType<StyleCompProps> = (props) => {
	const { compId, compPaths } = props
	return (
		<style
			id={`${compId}-paths-container`}
			dangerouslySetInnerHTML={{
				__html: `${compPaths}`,
			}}
		/>
	)
}

const RemoteStructureRenderer: ComponentType<RemoteStructureRendererProps> = (props) => {
	const { id, structure, compProps, rootCompId, compPathsToSelectors, stateRefs } = props
	const context = useContext(Context) as RendererProps
	const isDs = process.env.PACKAGE_NAME === 'thunderbolt-ds'

	if (!structure || !compProps || !rootCompId) {
		return null
	}

	const structureStore = extendStoreWithSubscribe(
		getStore<AppStructure>(),
		context.batchingStrategy,
		context.layoutDoneService
	)
	structureStore.update(structure)

	const propsStore = extendStoreWithSubscribe(
		getStore<PropsMap>(),
		context.batchingStrategy,
		context.layoutDoneService
	)
	propsStore.update(compProps) // TODO run inner elements mappers somehow

	const stateRefsStore = extendStoreWithSubscribe(
		getStore<PropsMap>(),
		context.batchingStrategy,
		context.layoutDoneService
	)
	stateRefsStore.update(stateRefs)

	const scopedContextValue = {
		...context,
		stateRefs: stateRefsStore,
		structure: structureStore,
		props: propsStore,
	} as RendererProps

	return (
		<Context.Provider value={scopedContextValue}>
			<div id={id} className={`${id} variants-kyldlyx0`}>
				{isDs && <CompPathsStyleComp compId={id} compPaths={compPathsToSelectors} />}
				<StructureComponent
					id={rootCompId}
					scopeData={{
						scope: [],
						repeaterItemsIndexes: [],
					}}
				/>
			</div>
		</Context.Provider>
	)
}

export default RemoteStructureRenderer
