import React, { ComponentType } from 'react'
import { withDependencies } from '@wix/thunderbolt-ioc'
import { CompProps } from '@wix/thunderbolt-symbols'

const isCsr = !!process.env.browser

let useControllerHook: (
	displayedId: string,
	compType: string,
	_compProps: CompProps,
	compId: string
) => {
	[x: string]: any
}
;(async () => {
	isCsr && (await window.externalsRegistry.react.loaded)
	useControllerHook = require('./hooks').useControllerHook
})()
export const RunControllersWrapper = withDependencies([], () => {
	return {
		wrapComponent: (Component: ComponentType<any>) => {
			const Wrapper = ({
				compProps: storeProps,
				...restProps
			}: {
				compProps: any
				compId: string
				compClassType: string
				id: string
			}) => {
				const { id: displayedId, compId, compClassType } = restProps
				const compProps = useControllerHook(displayedId, compClassType, storeProps, compId)

				return (
					<Component
						{...compProps}
						className={compProps?.className ? `${compProps.className} ${compId}` : compId}
						{...restProps}
					/>
				)
			}
			return Wrapper
		},
	}
})
