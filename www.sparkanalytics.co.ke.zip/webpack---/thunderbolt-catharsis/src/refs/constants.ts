export const COMPS_ROOT_NAMESPACE = 'comps-root'
