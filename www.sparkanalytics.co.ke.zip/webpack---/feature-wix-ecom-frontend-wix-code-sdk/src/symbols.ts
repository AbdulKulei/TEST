export const name = 'wixEcomFrontendWixCodeSdk' as const
export const namespace = 'ecom' as const
