export const name = 'mobileFullScreen' as const
export const TpaFullScreenModeAPISymbol = Symbol('TpaFullScreenModeAPI')
