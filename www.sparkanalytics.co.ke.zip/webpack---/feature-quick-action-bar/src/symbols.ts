export const name = 'quickActionBar' as const
export { DynamicActionsApiSymbol } from '@wix/thunderbolt-symbols'

export const DynamicActionsConfigSymbol = Symbol('DynamicActionsConfig')
