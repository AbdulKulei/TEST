export const name = 'businessLogger' as const
export const BsiManagerSymbol = Symbol('BsiManager')
