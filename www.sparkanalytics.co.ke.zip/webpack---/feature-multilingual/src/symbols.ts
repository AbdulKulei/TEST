export const name = 'multilingual' as const
export const MultilingualSymbol = Symbol.for('Multilingual')
export const MultilingualLinkUtilsAPISymbol = Symbol('MultilingualLinkUtilsAPI')
