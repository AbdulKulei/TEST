export const SvgContentBuilderSymbol = Symbol('SvgContentBuilder')

export const name = 'svgLoader' as const
