import { initCustomElementsDropdownMenu } from '@wix/custom-elements'

initCustomElementsDropdownMenu()
