export const CaptchaApiSymbol = Symbol('CaptchaApi')
export const DIALOG_COMPONENT_ID = 'CAPTCHA_DIALOG_ROOT_COMP' as const
