export const MultilingualCurrentLanguageSymbol = Symbol('currentLanguage')
