export const BeckyPropsInitialStoreSym = Symbol('BeckyPropsInitialStoreSym')
