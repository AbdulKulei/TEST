export const SITE_STYLES = 'SITE_STYLES'
export const SITE_FONTS = 'SITE_FONTS'
