export const SSR_DONE_MSG = '----SSR Done----'
