export const name = 'cyclicTabbing' as const

export const CyclicTabbingSymbol = Symbol('CyclicTabbing')
